from __future__ import annotations

import csv
import io
import os
from collections import Counter
from datetime import datetime, timedelta, timezone

import requests
from flask import Flask, jsonify, render_template, request
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///' + os.path.join(os.path.abspath(os.path.dirname(__file__)), 'orders.db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

class Order(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    track_order = db.Column(db.String(100), unique=True, nullable=False)
    tim = db.Column(db.String(100))
    workorder = db.Column(db.String(100))
    odc = db.Column(db.String(100))
    status = db.Column(db.String(100))
    status_morning = db.Column(db.String(100))
    catatan = db.Column(db.Text)
    jam_re = db.Column(db.String(50))
    jam_ps = db.Column(db.String(50))
    status_date_raw = db.Column(db.String(100))
    status_date_parsed = db.Column(db.String(20))
    date_created_raw = db.Column(db.String(100))
    date_created_parsed = db.Column(db.String(20))
    crm_order_type = db.Column(db.String(100))
    product_name = db.Column(db.String(255))
    tgl_ps = db.Column(db.String(50))
    tgl_ps_parsed = db.Column(db.String(20))
    workzone = db.Column(db.String(100))
    dispatch_date = db.Column(db.String(20)) # New field for DISPATCH column

    def to_dict(self):
        return {
            "TIM": self.tim,
            "track_order": self.track_order,
            "Workorder": self.workorder,
            "ODC": self.odc,
            "Status": self.status,
            "status morning": self.status_morning,
            "Catatan": self.catatan,
            "Jam re": self.jam_re,
            "Jam PS": self.jam_ps,
            "Status Date": self.status_date_raw,
            "status_date_parsed": self.status_date_parsed,
            "Date Created": self.date_created_raw,
            "date_created_parsed": self.date_created_parsed,
            "crm_order_type": self.crm_order_type,
            "product_name": self.product_name,
            "tgl_ps": self.tgl_ps,
            "tgl_ps_parsed": self.tgl_ps_parsed,
            "workzone": self.workzone,
            "dispatch_date": self.dispatch_date
        }



SHEET_CSV_URL = (
    "https://docs.google.com/spreadsheets/d/e/"
    "2PACX-1vQhJ14Fz-jQmorjsI3LYacfF-URCZ_vdh9vKiv0arRSri8PSsmkslChsUWKkPTyD5hXQX1A_gQO_8cA/"
    "pub?gid=0&single=true&output=csv"
)


def normalize_text(value: str | None) -> str:
    return (value or "").strip()


def normalize_upper(value: str | None) -> str:
    return normalize_text(value).upper()


def fetch_sheet_rows() -> list[dict[str, str]]:
    response = requests.get(SHEET_CSV_URL, timeout=30)
    response.raise_for_status()
    content = response.content.decode("utf-8-sig", errors="replace")
    return list(csv.DictReader(io.StringIO(content)))


def is_truthy_text(value: str) -> bool:
    return normalize_text(value) != ""


def parse_sheet_date(value: str) -> str:
    text = normalize_text(value)
    if not text:
        return ""

    formats = [
        "%Y-%m-%d %H:%M:%S.%f",
        "%Y-%m-%d %H:%M:%S",
        "%m/%d/%Y",
        "%Y-%m-%d",
        "%m/%d/%Y %H:%M:%S",
    ]
    for fmt in formats:
        try:
            return datetime.strptime(text, fmt).strftime("%Y-%m-%d")
        except ValueError:
            continue
    return text[:10] if len(text) >= 10 else text


def dedupe_rows(rows: list[dict[str, str]]) -> list[dict[str, str]]:
    preferred_statuses = {
        "COMPWORK": 5,
        "WORKFAIL": 4,
        "STARTWORK": 3,
        "VALCOMP": 2,
        "ACTCOMP": 1,
        "VALSTART": 0,
    }
    buckets: dict[str, dict[str, str]] = {}

    for row in rows:
        track_order = normalize_text(row.get("track_order"))
        if not track_order:
            track_order = normalize_text(row.get("SC Order No/Track ID/CSRM No"))
        if not track_order:
            continue

        current = buckets.get(track_order)
        if current is None:
            buckets[track_order] = row
            continue

        current_score = preferred_statuses.get(normalize_upper(current.get("Status")), -1)
        new_score = preferred_statuses.get(normalize_upper(row.get("Status")), -1)
        if new_score >= current_score:
            buckets[track_order] = row

    return list(buckets.values())


def match_status(row: dict[str, str], allowed: set[str]) -> bool:
    val = row.get("Status") or row.get("status")
    return normalize_upper(val) in allowed


def match_status_morning(row: dict[str, str], expected: str) -> bool:
    val = row.get("status morning") or row.get("status_morning")
    return normalize_upper(val) == expected.upper()


def get_product_name_normalized(row: dict) -> str:
    product_name = normalize_upper(row.get("product_name") or row.get("Product Name") or "")
    tr_order = normalize_upper(row.get("track_order") or row.get("track_order") or "")
    if not product_name or product_name in {"-", "UNKNOWN", ""}:
        if tr_order.startswith("PDA"):
            return "PDA"
        elif tr_order.startswith("SC"):
            return "INDIBIZ"
        elif tr_order.startswith("TIF"):
            return "VULA"
        elif tr_order.startswith("AO") or tr_order.startswith("MYIR") or tr_order.startswith("IN"):
            return "INDIHOME"
        else:
            return "UNKNOWN"
    return product_name


def filter_by_date(rows: list[dict[str, str]], start_date: str, end_date: str) -> list[dict[str, str]]:
    if not start_date and not end_date:
        return rows

    filtered = []
    for row in rows:
        row_date = parse_sheet_date(row.get("Status Date", ""))
        if start_date and row_date and row_date < start_date:
            continue
        if end_date and row_date and row_date > end_date:
            continue
        if not row_date and (start_date or end_date):
            continue
        filtered.append(row)
    return filtered


def build_summary(all_rows: list[dict[str, str]], total_ps_rows: list[dict[str, str]]) -> dict[str, any]:
    # Categories for summary breakdown
    categories = {
        "ps": [],
        "potensi": [],
        "ogp": [],
        "oke": [],
        "belum": [],
        "undispatch": []
    }

    for row in total_ps_rows:
        if match_status(row, {"COMPWORK"}):
            categories["ps"].append(row)

    for row in all_rows:
        st_up = normalize_upper(row.get("Status"))
        sm_up = normalize_upper(row.get("status morning"))
        # Keywords for Potensi (including space variations and typos for robustness)
        potensi_keywords = {"VALSTART", "VAL START", "ACTCOMP", "ACT COMP", "ACTCOPM", "VALCOMP", "VAL COMP"}
        is_potensi_st = any(v in st_up for v in potensi_keywords)
        is_setting_sm = "SETTING" in sm_up
        
        if is_potensi_st or is_setting_sm:
            categories["potensi"].append(row)
        
        if match_status_morning(row, "SEDANG DIKERJAKAN"):
            categories["ogp"].append(row)
        
        is_wf_sw = match_status(row, {"WORKFAIL", "STARTWORK"})
        if is_wf_sw:
            status_m = normalize_upper(row.get("status morning"))
            tim = normalize_text(row.get("TIM"))
            
            if status_m == "OKE TARIK":
                categories["oke"].append(row)
            
            if status_m in {"BELUM DIKERJAKAN", ""} and is_truthy_text(tim) and tim != "-":
                categories["belum"].append(row)
            
            if not is_truthy_text(tim) or tim == "-":
                categories["undispatch"].append(row)

    def get_breakdown(rows):
        counter: Counter[str] = Counter()
        for r in rows:
            pname = get_product_name_normalized(r)
            counter[pname] += 1
        return [{"product": k, "count": v} for k, v in counter.most_common()]

    return {
        "total_ps": len(categories["ps"]),
        "total_potensi": len(categories["potensi"]),
        "sedang_ogp": len(categories["ogp"]),
        "oke_tarik": len(categories["oke"]),
        "belum_dikerjakan": len(categories["belum"]),
        "undispatch": len(categories["undispatch"]),
        "total_rows": len(all_rows),
        "ps_breakdown": get_breakdown(categories["ps"]),
        "potensi_breakdown": get_breakdown(categories["potensi"]),
        "ogp_breakdown": get_breakdown(categories["ogp"]),
        "oke_breakdown": get_breakdown(categories["oke"]),
        "belum_breakdown": get_breakdown(categories["belum"]),
        "undispatch_breakdown": get_breakdown(categories["undispatch"])
    }


def build_hour_chart(rows: list[dict[str, str]], column_name: str) -> dict[str, list]:
    counter: Counter[str] = Counter()
    product_counter: Counter[str] = Counter()
    total_count = 0
    for row in rows:
        value = normalize_text(row.get(column_name))
        if not value:
            continue
        counter[value] += 1
        total_count += 1
        
        pname = get_product_name_normalized(row)
        product_counter[pname] += 1

    def sort_key(item: str) -> tuple[int, str]:
        try:
            return (int(item), item)
        except ValueError:
            return (999, item)

    labels = sorted(counter.keys(), key=sort_key)
    values = [counter[label] for label in labels]
    breakdown = [{"product": k, "count": v} for k, v in product_counter.most_common()]
    return {"labels": labels, "values": values, "total": total_count, "breakdown": breakdown}


def build_table_rows(rows: list[dict[str, str]]) -> list[dict[str, str]]:
    table_rows = []
    for row in rows:
        table_rows.append(
            {
                "workzone": normalize_text(row.get("workzone")),
                "tim": normalize_text(row.get("TIM")),
                "track_order": normalize_text(row.get("track_order")),
                "workorder": normalize_text(row.get("Workorder")),
                "odc": normalize_text(row.get("ODC")),
                "status": normalize_text(row.get("Status")),
                "status_morning": normalize_text(row.get("status morning")),
                "catatan": normalize_text(row.get("Catatan")),
                "jam_re": normalize_text(row.get("Jam re")),
                "jam_ps": normalize_text(row.get("Jam PS")),
                "datevalue": parse_sheet_date(row.get("Status Date", "")),
            }
        )
    return table_rows


def sync_orders():
    rows = fetch_sheet_rows()
    deduped_rows = dedupe_rows(rows)
    
    preferred_statuses = {
        "COMPWORK": 5,
        "WORKFAIL": 4,
        "STARTWORK": 3,
        "VALCOMP": 2,
        "ACTCOMP": 1,
        "VALSTART": 0,
    }

    synced_count = 0
    # Fetch existing to handle upsert quickly
    all_db_orders = Order.query.all()
    existing_orders = {o.track_order: o for o in all_db_orders}
    
    # Track IDs that are present in the current sheet sync
    current_sheet_ids = set()
    
    for row_dict in deduped_rows:
        tr_order = normalize_text(row_dict.get("track_order") or row_dict.get("SC Order No/Track ID/CSRM No"))
        if not tr_order:
            continue

        existing = existing_orders.get(tr_order)
        new_status_score = preferred_statuses.get(normalize_upper(row_dict.get("Status")), -1)
        
        parsed_date = parse_sheet_date(row_dict.get("Status Date", ""))
        date_created_val = row_dict.get("Date Created", "")
        parsed_created_date = parse_sheet_date(date_created_val)
        parsed_tgl_ps = parse_sheet_date(row_dict.get("tgl ps", ""))
        parsed_dispatch = parse_sheet_date(row_dict.get("DISPATCH", ""))

        if existing:
            existing_status_score = preferred_statuses.get(normalize_upper(existing.status), -1)
            # update if new status is higher or equal
            if new_status_score >= existing_status_score:
                existing.tim = normalize_text(row_dict.get("TIM"))
                existing.workorder = normalize_text(row_dict.get("Workorder"))
                existing.odc = normalize_text(row_dict.get("ODC"))
                existing.status = normalize_text(row_dict.get("Status"))
                # Robust mapping for status morning
                existing.status_morning = normalize_text(row_dict.get("status morning") or row_dict.get("Status Morning") or row_dict.get("status_morning"))
                existing.catatan = normalize_text(row_dict.get("Catatan"))
                existing.jam_re = normalize_text(row_dict.get("Jam re"))
                existing.jam_ps = normalize_text(row_dict.get("Jam PS"))
                existing.status_date_raw = normalize_text(row_dict.get("Status Date"))
                existing.status_date_parsed = parsed_date
                existing.date_created_raw = normalize_text(date_created_val)
                existing.date_created_parsed = parsed_created_date
                existing.crm_order_type = normalize_text(row_dict.get("CRM Order Type"))
                existing.product_name = normalize_text(row_dict.get("Product Name"))
                existing.tgl_ps = normalize_text(row_dict.get("tgl ps"))
                existing.tgl_ps_parsed = parsed_tgl_ps
                existing.workzone = normalize_text(row_dict.get("Workzone"))
                existing.dispatch_date = parsed_dispatch
        else:
            new_order = Order(
                track_order=tr_order,
                tim=normalize_text(row_dict.get("TIM")),
                workorder=normalize_text(row_dict.get("Workorder")),
                odc=normalize_text(row_dict.get("ODC")),
                status=normalize_text(row_dict.get("Status")),
                # Robust mapping for status morning
                status_morning=normalize_text(row_dict.get("status morning") or row_dict.get("Status Morning") or row_dict.get("status_morning")),
                catatan=normalize_text(row_dict.get("Catatan")),
                jam_re=normalize_text(row_dict.get("Jam re")),
                jam_ps=normalize_text(row_dict.get("Jam PS")),
                status_date_raw=normalize_text(row_dict.get("Status Date")),
                status_date_parsed=parsed_date,
                date_created_raw=normalize_text(date_created_val),
                date_created_parsed=parsed_created_date,
                crm_order_type=normalize_text(row_dict.get("CRM Order Type")),
                product_name=normalize_text(row_dict.get("Product Name")),
                tgl_ps=normalize_text(row_dict.get("tgl ps")),
                tgl_ps_parsed=parsed_tgl_ps,
                workzone=normalize_text(row_dict.get("Workzone")),
                dispatch_date=parsed_dispatch
            )
            db.session.add(new_order)
            existing_orders[tr_order] = new_order
        
        current_sheet_ids.add(tr_order)
        synced_count += 1
        
    # Identify and delete "ghost" records no longer in the Google Sheet
    db_ids = set(existing_orders.keys())
    ids_to_delete = db_ids - current_sheet_ids
    
    if ids_to_delete:
        print(f"Sync: Deleting {len(ids_to_delete)} ghost records not found in Google Sheet.")
        Order.query.filter(Order.track_order.in_(ids_to_delete)).delete(synchronize_session=False)

    db.session.commit()
    return synced_count


def load_dashboard_data(start_date: str, end_date: str, sektor: str = "") -> dict:
    query = Order.query
    if start_date:
        query = query.filter(Order.status_date_parsed >= start_date)
    if end_date:
        query = query.filter(Order.status_date_parsed <= end_date)

    filtered_db_rows = query.all()
    filtered_rows = [o.to_dict() for o in filtered_db_rows]

    # Special fetch for matrix (DISPATCH): All rows that might be needed
    # (either DISPATCH == today OR status_morning is active/pending)
    all_db_rows = Order.query.all()
    matrix_source_rows = [o.to_dict() for o in all_db_rows]

    # Determine "Today" context for metrics
    # Default to current WITA (GMT+8) time
    now_utc = datetime.now(timezone.utc)
    now_wita = now_utc + timedelta(hours=8)
    default_today_wita = now_wita.strftime("%Y-%m-%d")

    # If end_date filter is present, use it as the "today" reference for PS and Ranking
    today = end_date or default_today_wita
    today_month = today[:7]
    
    today_db_rows = Order.query.filter(Order.status_date_parsed == today).all()
    today_rows = [o.to_dict() for o in today_db_rows]

    if sektor:
        sektor_map = {
            "batulicin": {"BLC", "SER"},
            "satui": {"STI", "PGT", "KIP"},
            "kotabaru": {"KPL"}
        }
        allowed_wz = sektor_map.get(sektor.lower())
        if allowed_wz:
            filtered_rows = [r for r in filtered_rows if normalize_upper(r.get("workzone")) in allowed_wz]
            today_rows = [r for r in today_rows if normalize_upper(r.get("workzone")) in allowed_wz]
            matrix_source_rows = [r for r in matrix_source_rows if normalize_upper(r.get("workzone")) in allowed_wz]

    # ── Matrix + Ranking ──────────────────────────────────────────────────────
    matrix_rows_flat = []
    tim_today_counter: Counter = Counter()
    tim_mtd_counter: Counter = Counter()

    # We group by (Workzone + TIM) to determine if that group has any OGP status
    team_status_map = {} # (workzone, tim) -> is_ogp
    
    for row in matrix_source_rows:
        tim = normalize_text(row.get("TIM"))
        wz = normalize_text(row.get("workzone"))
        status_morning_up = normalize_upper(row.get("status morning"))
        
        if not is_truthy_text(tim) or tim == "-":
            continue
            
        key = (wz.lower(), tim.lower())
        if key not in team_status_map:
            team_status_map[key] = False
            
        if status_morning_up in {"SEDANG DIKERJAKAN", "PROSES SETTING"}:
            team_status_map[key] = True

    for row in matrix_source_rows:
        status_up = normalize_upper(row.get("Status"))
        tim = normalize_text(row.get("TIM"))
        wz = normalize_text(row.get("workzone"))
        status_morning_up = normalize_upper(row.get("status morning"))
        dispatch_date = row.get("dispatch_date")

        is_today = (dispatch_date == today)
        # Robust check for status variations
        potensi_keywords = {"VALSTART", "VAL START", "ACTCOMP", "ACT COMP", "ACTCOPM", "VALCOMP", "VAL COMP"}
        is_potensi_st = any(v in status_up for v in potensi_keywords)
        is_setting_sm = "SETTING" in status_morning_up
        is_potensi = is_potensi_st or is_setting_sm

        # 1. Skip WAPPR only if it's NOT a Potensi row (Potensi are usually WAPPR initially)
        if status_up == "WAPPR" and not is_potensi:
            continue
            
        if not is_truthy_text(tim) or tim == "-":
            continue
            
        is_persistent = (status_morning_up in {
            "SEDANG DIKERJAKAN", "BELUM DIKERJAKAN", "", 
            "MATERIAL/NTE", "MATERIAL / NTE", "PENDING", "PROSES SETTING"
        } or is_potensi)
        
        if not is_today and not is_persistent:
            continue
            
        # Keep current COMPWORK today logic
        if status_up == "COMPWORK" and row.get("tgl_ps_parsed") != today:
            continue

        is_ps_today = (status_up == "COMPWORK" and row.get("tgl_ps_parsed") == today)
        status_morning_up = normalize_upper(row.get("status morning"))

        if status_up == "COMPWORK":
            color_class = "success"
        elif "SETTING" in status_morning_up:
            color_class = "primary"
        elif "SEDANG DIKERJAKAN" in status_morning_up:
            color_class = "warning"
        elif status_morning_up == "OKE TARIK":
            color_class = "info"
        elif status_morning_up in {"BELUM DIKERJAKAN", ""}:
            color_class = "secondary"
        else:
            color_class = "danger"

        # Determine team flag (OGP/IDLE) for grouping indicators
        key = (wz.lower(), tim.lower())
        is_p_ogp = team_status_map.get(key, False)
        team_flag = "OGP" if is_p_ogp else "IDLE"

        # Determine special badges (Robust matching for data variations)
        status_m_up = normalize_upper(row.get("status morning"))
        is_ogp_status = ("SEDANG" in status_m_up or "SETTING" in status_m_up)
        is_hr = ("HR" in status_m_up)
        is_issue = any(kw in status_m_up for kw in {"KENDALA", "RUSAK", "IZIN", "ALAMAT", "FAILWA", "KENDALA"})
        is_no_update = (status_m_up in {"", "-", "KOSONG"} or "BELUM" in status_m_up)

        matrix_rows_flat.append({
            "tim": tim,
            "workzone": wz,
            "track_order": normalize_text(row.get("track_order")),
            "odc": normalize_text(row.get("ODC")),
            "status": status_up,
            "status_morning": normalize_text(row.get("status morning")),
            "catatan": normalize_text(row.get("Catatan")),
            "product_name": row.get("product_name") or row.get("Product Name") or "-",
            "color_class": color_class,
            "is_ps_today": is_ps_today,
            "is_ogp_status": is_ogp_status,
            "is_hr": is_hr,
            "is_issue": is_issue,
            "is_no_update": is_no_update,
            "team_flag": team_flag
        })

    for row in filtered_rows:
        status_up = normalize_upper(row.get("Status"))
        tim = normalize_text(row.get("TIM"))
        if not is_truthy_text(tim) or tim == "-":
            continue
        if status_up == "COMPWORK":
            tgl_ps = row.get("tgl_ps_parsed") or ""
            if tgl_ps == today:
                tim_today_counter[tim] += 1
            if tgl_ps.startswith(today_month):
                tim_mtd_counter[tim] += 1

    top_tim_today = [{"tim": k, "count": v} for k, v in tim_today_counter.most_common(5)]
    top_tim_mtd = [{"tim": k, "count": v} for k, v in tim_mtd_counter.most_common(5)]
    
    # Sort matrix flat list per workzone, then tim, then odc
    matrix_rows_flat.sort(key=lambda x: (
        (x["workzone"] or "").lower(),
        (x["tim"] or "").lower(),
        (x["odc"] or "").lower()
    ))
    matrix_rows = matrix_rows_flat

    # ── Kendala / Pending / Failwa ────────────────────────────────────────────
    kendala_fu_table = []
    cek_pending_table = []

    for row in filtered_rows:
        status_up = normalize_upper(row.get("Status"))
        status_morning_up = normalize_upper(row.get("status morning"))
        tim_val = row.get("TIM") or "-"
        if status_up in {"WORKFAIL", "STARTWORK"}:
            if status_morning_up in {"INSERT TIANG", "ODP RUSAK"}:
                kendala_fu_table.append({
                    "tim": tim_val,
                    "track_order": row.get("track_order", "-"),
                    "status_morning": row.get("status morning", "-"),
                    "catatan": row.get("Catatan", "-")
                })
            if status_morning_up in {"PENDING", "OKE TARIK", "MATERIAL/NTE", "MATERIAL / NTE"}:
                cek_pending_table.append({
                    "tim": tim_val,
                    "track_order": row.get("track_order", "-"),
                    "status_morning": row.get("status morning", "-"),
                    "catatan": row.get("Catatan", "-")
                })

    # Failwa: STARTWORK + datevalue (status_date_parsed) < hari ini
    failwa_count = sum(
        1 for o in Order.query.all()
        if normalize_upper(o.status) == "STARTWORK"
        and o.status_date_parsed
        and o.status_date_parsed < today
    )

    # Undispatch (untuk floating widget)
    undispatch_count = sum(
        1 for r in filtered_rows
        if normalize_upper(r.get("Status")) in {"WORKFAIL", "STARTWORK"}
        and not is_truthy_text(r.get("TIM", ""))
    )

    # Jam PS Chart -> Status Date (which is mapped to start_date / end_date filters)
    if start_date or end_date:
        jam_ps_source = [r for r in filtered_rows if normalize_upper(r.get("Status")) == "COMPWORK"]
    else:
        jam_ps_source = [r for r in today_rows if normalize_upper(r.get("Status")) == "COMPWORK"]
        
    # Jam RE Chart -> Date Created
    query_re = Order.query
    if start_date:
        query_re = query_re.filter(Order.date_created_parsed >= start_date)
    if end_date:
        query_re = query_re.filter(Order.date_created_parsed <= end_date)
    if not start_date and not end_date:
        query_re = query_re.filter(Order.date_created_parsed == today)
    
    re_db_rows = query_re.all()
    re_rows = [o.to_dict() for o in re_db_rows]
    if sektor:
        allowed_wz = {
            "batulicin": {"BLC", "SER"},
            "satui": {"STI", "PGT", "KIP"},
            "kotabaru": {"KPL"}
        }.get(sektor.lower())
        if allowed_wz:
            re_rows = [r for r in re_rows if normalize_upper(r.get("workzone")) in allowed_wz]

    # Exclude CNCLWORK and WAPPR from Jam RE
    re_rows = [r for r in re_rows if normalize_upper(r.get("Status")) not in {"CNCLWORK", "WAPPR"}]

    # Sort per Tim
    kendala_fu_table.sort(key=lambda x: (x.get("tim") or "").lower())
    cek_pending_table.sort(key=lambda x: (x.get("tim") or "").lower())

    # Count IDLE teams only from those currently in the Matrix (Today's teams)
    unique_teams_in_matrix = {} # tim -> team_flag
    for r in matrix_rows:
        tname = r.get("tim")
        if tname and tname != "-":
            unique_teams_in_matrix[tname] = r.get("team_flag")
            
    idle_teams_count = sum(1 for flag in unique_teams_in_matrix.values() if flag == "IDLE")

    # For the summary cards at the top, we use the global snapshot (matrix_source_rows)
    # so that metrics like "TOTAL POTENSI" show everything, not just today's updates.
    summary_data = build_summary(matrix_source_rows, today_rows)
    summary_data["idle_teams_count"] = idle_teams_count

    return {
        "source": "sqlite_database",
        "summary": summary_data,
        "jam_ps_chart": build_hour_chart(jam_ps_source, "Jam PS"),
        "jam_re_chart": build_hour_chart(re_rows, "Jam re"),
        "matrix_rows": matrix_rows,
        "row_count": len(filtered_rows),
        "today_date": today,
        "kendala_fu": kendala_fu_table,
        "cek_pending": cek_pending_table,
        "failwa_count": failwa_count,
        "undispatch_count": undispatch_count,
        "top_tim_today": top_tim_today,
        "top_tim_mtd": top_tim_mtd
    }


@app.route("/")
def index():
    filters = {
        "start_date": request.args.get("start_date", ""),
        "end_date": request.args.get("end_date", ""),
        "sektor": request.args.get("sektor", ""),
    }
    dashboard_data = load_dashboard_data(filters["start_date"], filters["end_date"], filters["sektor"])
    return render_template(
        "dashboard_order.html",
        filters=filters,
        data_source=dashboard_data["source"],
        summary=dashboard_data["summary"],
        jam_ps_chart=dashboard_data["jam_ps_chart"],
        jam_re_chart=dashboard_data["jam_re_chart"],
        matrix_rows=dashboard_data["matrix_rows"],
        row_count=dashboard_data["row_count"],
        today_date=dashboard_data["today_date"],
        kendala_fu=dashboard_data["kendala_fu"],
        cek_pending=dashboard_data["cek_pending"],
        failwa_count=dashboard_data["failwa_count"],
        undispatch_count=dashboard_data["undispatch_count"],
        top_tim_today=dashboard_data["top_tim_today"],
        top_tim_mtd=dashboard_data["top_tim_mtd"],
    )


last_sync_time = datetime.now()

@app.route("/api/dashboard/order")
def api_dashboard_order():
    global last_sync_time
    # Automatic Sync Check (if last sync > 15 minutes)
    if (datetime.now() - last_sync_time) > timedelta(minutes=15):
        try:
            sync_orders()
            last_sync_time = datetime.now()
            print("Auto-sync completed successfully.")
        except Exception as e:
            print(f"Auto-sync failed: {str(e)}")

    start_date = request.args.get("start_date", "")
    end_date = request.args.get("end_date", "")
    sektor = request.args.get("sektor", "")
    return jsonify(load_dashboard_data(start_date, end_date, sektor))


@app.route("/api/dashboard/detail")
def api_dashboard_detail():
    start_date = request.args.get("start_date", "")
    end_date = request.args.get("end_date", "")
    category = request.args.get("category", "")
    sektor = request.args.get("sektor", "")

    query = Order.query
    if start_date:
        query = query.filter(Order.status_date_parsed >= start_date)
    if end_date:
        query = query.filter(Order.status_date_parsed <= end_date)

    filtered_db_rows = query.all()
    filtered_rows = [o.to_dict() for o in filtered_db_rows]

    today = datetime.now().strftime("%Y-%m-%d")
    today_db_rows = Order.query.filter(Order.status_date_parsed == today).all()
    today_rows = [o.to_dict() for o in today_db_rows]

    if sektor:
        sektor_map = {
            "batulicin": {"BLC", "SER"},
            "satui": {"STI", "PGT", "KIP"},
            "kotabaru": {"KPL"}
        }
        allowed_wz = sektor_map.get(sektor.lower())
        if allowed_wz:
            filtered_rows = [r for r in filtered_rows if normalize_upper(r.get("workzone")) in allowed_wz]
            today_rows = [r for r in today_rows if normalize_upper(r.get("workzone")) in allowed_wz]

    result = []
    if category == "total_ps":
        result = [r for r in today_rows if normalize_upper(r.get("Status")) == "COMPWORK"]
    elif category == "total_potensi":
        result = []
        for r in filtered_rows:
            st_up = normalize_upper(r.get("Status"))
            sm_up = normalize_upper(r.get("status morning"))
            potensi_keywords = {"VALSTART", "VAL START", "ACTCOMP", "ACT COMP", "ACTCOPM", "VALCOMP", "VAL COMP"}
            if any(v in st_up for v in potensi_keywords) or "SETTING" in sm_up:
                result.append(r)
    elif category == "sedang_ogp":
        result = [r for r in filtered_rows if normalize_upper(r.get("status morning")) == "SEDANG DIKERJAKAN"]
    elif category == "oke_tarik":
        result = [r for r in filtered_rows if normalize_upper(r.get("Status")) in {"WORKFAIL", "STARTWORK"} and normalize_upper(r.get("status morning")) == "OKE TARIK"]
    elif category == "belum_dikerjakan":
        result = [
            r for r in filtered_rows
            if normalize_upper(r.get("Status")) in {"WORKFAIL", "STARTWORK"}
            and normalize_upper(r.get("status morning")) in {"BELUM DIKERJAKAN", ""}
            and is_truthy_text(r.get("TIM"))
            and str(r.get("TIM")).strip() != "-"
        ]
    elif category == "undispatch":
        result = [r for r in filtered_rows if normalize_upper(r.get("Status")) in {"WORKFAIL", "STARTWORK"} and not is_truthy_text(r.get("TIM", ""))]
    elif category == "idle_teams":
        # Logic to identify IDLE teams from Matrix source
        now_utc = datetime.now(timezone.utc)
        now_wita = now_utc + timedelta(hours=8)
        today_wita = now_wita.strftime("%Y-%m-%d")
        persistent_statuses = {"SEDANG DIKERJAKAN", "PENDING", "MATERIAL/NTE", "PROSES SETTING", "BELUM DIKERJAKAN"}

        all_rows_list = [o.to_dict() for o in Order.query.all()]
        if sektor:
            sektor_map = {"batulicin": {"BLC", "SER"}, "satui": {"STI", "PGT", "KIP"}, "kotabaru": {"KPL"}}
            allowed_wz = sektor_map.get(sektor.lower(), set())
            all_rows_list = [r for r in all_rows_list if normalize_upper(r.get("workzone")) in allowed_wz]

        matrix_rows_source = []
        for r in all_rows_list:
            is_today = r.get("dispatch_date") == today_wita
            is_persistent = normalize_upper(r.get("status morning")) in persistent_statuses
            if is_today or is_persistent:
                matrix_rows_source.append(r)

        team_status_map = {}
        for r in matrix_rows_source:
            tim = normalize_text(r.get("TIM"))
            if not is_truthy_text(tim) or tim == "-": continue
            status_m_up = normalize_upper(r.get("status morning"))
            if tim.lower() not in team_status_map: team_status_map[tim.lower()] = False
            if status_m_up in {"SEDANG DIKERJAKAN", "PROSES SETTING"}:
                team_status_map[tim.lower()] = True
        
        idle_teams = sorted(list({t for t, is_ogp in team_status_map.items() if not is_ogp}))
        return jsonify({"success": True, "data": [{"tim": t.upper()} for t in idle_teams]})
    else:
        result = []

    detail_rows = []
    for r in result:
        # Fallback if product_name is "-" or empty
        pname = r.get("product_name")
        if not pname or pname == "-":
            pname = get_product_name_normalized(r)
            
        detail_rows.append({
            "status": r.get("Status", "-"),
            "track_order": r.get("track_order", "-"),
            "workorder": r.get("Workorder", "-"),
            "product_name": pname,
            "odc": r.get("ODC", "-"),
            "tim": r.get("TIM", "-"),
            "status_morning": r.get("status morning") or "EMPTY",
            "catatan": r.get("Catatan", "-")
        })

    return jsonify({"success": True, "data": detail_rows})


@app.route("/api/sync", methods=["POST"])
def api_sync():
    try:
        count = sync_orders()
        return jsonify({"success": True, "message": f"Berhasil sinkronisasi {count} data"})
    except Exception as e:
        return jsonify({"success": False, "message": str(e)}), 500


with app.app_context():
    db.create_all()

if __name__ == "__main__":
    with app.app_context():
        if Order.query.first() is None:
            print("Database kosong, melakukan sinkronisasi awal dari Google Sheets...")
            sync_orders()
            print("Sinkronisasi awal selesai.")
    app.run(debug=True, host="0.0.0.0", port=5000)
