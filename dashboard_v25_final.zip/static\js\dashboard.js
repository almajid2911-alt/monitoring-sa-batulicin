(function () {
  const jamPs = JSON.parse(document.getElementById("jam-ps-data").textContent);
  const jamRe = JSON.parse(document.getElementById("jam-re-data").textContent);

  // ─── Badge Modal Helper ───────────────────────────────────────────────────
  function showBadgeModal(track, status, morning, catatan) {
    $("#badge-modal-tr").text(track);
    $("#badge-modal-status").text(status);
    $("#badge-modal-morning").text(morning);
    $("#badge-modal-catatan").html((catatan || "-").replace(/\n/g, "<br/>"));
    var bm = bootstrap.Modal.getOrCreateInstance(document.getElementById("badgeModal"));
    bm.show();
  }

  // ─── DataTable: 3 cols, col0 = WORKZONE hidden, rowGroup by Workzone ─────
  let dataTable = $("#detailTable").DataTable({
    paging: true,
    pageLength: 50,
    searching: true,
    info: true,
    ordering: true,
    order: [[0, "asc"], [1, "asc"], [3, "asc"]],
    rowGroup: { dataSrc: 0 },
    columnDefs: [{ targets: [0], visible: false, searchable: false }],
    scrollX: false,
    language: {
      search: "Cari:",
      lengthMenu: "Tampilkan _MENU_ data",
      info: "Menampilkan _START_ sampai _END_ dari _TOTAL_ data",
      paginate: { previous: "←", next: "→" },
      zeroRecords: "Tidak ada data yang cocok",
      infoEmpty: "Tidak ada data",
      infoFiltered: "(difilter dari _MAX_ total data)",
    },
    rowCallback: function (row, data, displayNum, displayIndex) {
      const api = this.api();
      const currentTim = data[1] || ""; // Raw TIM value
      const currentWz = data[0] || ""; // Raw Workzone value

      if (displayIndex > 0) {
        const prevData = api.row(displayIndex - 1, { page: "current" }).data();
        const prevTim = prevData[1] || "";
        const prevWz = prevData[0] || "";

        if (currentTim === prevTim && currentWz === prevWz && currentTim !== "-" && currentTim !== "") {
          // Hide team name cell visually for merged rows
          $(row).find("td:first").addClass("tim-cell-merged");
        } else {
          $(row).addClass("tim-group-start");
        }
      } else {
        $(row).addClass("tim-group-start");
      }
    },
  });

  // ─── Chart Options ────────────────────────────────────────────────────────
  const commonOptions = {
    responsive: true,
    maintainAspectRatio: false,
    scales: {
      y: {
        beginAtZero: true,
        grid: { color: "rgba(148, 163, 184, 0.16)", drawBorder: false },
        ticks: { precision: 0, color: "#64748b" },
      },
      x: {
        grid: { display: false },
        ticks: { color: "#64748b" },
      },
    },
    plugins: {
      legend: { display: false },
      tooltip: {
        backgroundColor: "rgba(15, 23, 42, 0.92)",
        titleColor: "#fff",
        bodyColor: "#e2e8f0",
        padding: 12,
        cornerRadius: 12,
      },
    },
  };

  let psChartInstance = new Chart(document.getElementById("jamPsChart"), {
    type: "line",
    data: {
      labels: jamPs.labels,
      datasets: [{
        label: "Jumlah Order",
        data: jamPs.values,
        borderColor: "rgba(34, 197, 94, 1)",
        backgroundColor: "rgba(34, 197, 94, 0.12)",
        fill: true,
        tension: 0.35,
        pointRadius: 4,
        pointHoverRadius: 5,
        pointBackgroundColor: "#22c55e",
      }],
    },
    options: commonOptions,
  });

  let reChartInstance = new Chart(document.getElementById("jamReChart"), {
    type: "line",
    data: {
      labels: jamRe.labels,
      datasets: [{
        label: "Jumlah Order",
        data: jamRe.values,
        borderColor: "rgba(37, 99, 235, 1)",
        backgroundColor: "rgba(37, 99, 235, 0.12)",
        fill: true,
        tension: 0.35,
        pointRadius: 4,
        pointHoverRadius: 5,
        pointBackgroundColor: "#2563eb",
      }],
    },
    options: commonOptions,
  });

  // ─── Update Dashboard Data (auto refresh) ─────────────────────────────────
  function updateDashboardData() {
    const urlParams = new URLSearchParams(window.location.search);
    const startDate = urlParams.get("start_date") || "";
    const endDate = urlParams.get("end_date") || "";
    const sektor = urlParams.get("sektor") || "";

    fetch(`/api/dashboard/order?start_date=${startDate}&end_date=${endDate}&sektor=${sektor}`)
      .then(res => res.json())
      .then(data => {
        // Update metric cards
        const u = (id, val, bd) => {
          const el = document.getElementById(id);
          if (el) el.textContent = val;
          const bEl = document.getElementById(id.replace("metric-", "") + "-breakdown-container");
          if (bEl && bd) {
            bEl.innerHTML = bd.map(b => `<span class="badge-soft-summary">*${b.product} : ${b.count}</span>`).join("");
          }
        };

        u("metric-total-ps", data.summary.total_ps, data.summary.ps_breakdown);
        u("metric-total-potensi", data.summary.total_potensi, data.summary.potensi_breakdown);
        u("metric-sedang-ogp", data.summary.sedang_ogp, data.summary.ogp_breakdown);
        u("metric-oke-tarik", data.summary.oke_tarik, data.summary.oke_breakdown);
        u("metric-belum-dikerjakan", data.summary.belum_dikerjakan, data.summary.belum_breakdown);
        u("metric-undispatch", data.summary.undispatch, data.summary.undispatch_breakdown);

        // Update Failwa
        const failwaEl = document.getElementById("metric-failwa");
        if (failwaEl && data.failwa_count !== undefined) failwaEl.textContent = data.failwa_count;

        // Update Floating Undispatch
        const floatUnd = document.getElementById("floating-undispatch-count");
        if (floatUnd && data.undispatch_count !== undefined) floatUnd.textContent = data.undispatch_count;

        // Update Charts
        psChartInstance.data.labels = data.jam_ps_chart.labels;
        psChartInstance.data.datasets[0].data = data.jam_ps_chart.values;
        psChartInstance.update();
        document.getElementById("dist-ps-count").textContent = `(${data.jam_ps_chart.total || 0})`;
        if (document.getElementById("dist-ps-breakdown") && data.jam_ps_chart.breakdown) {
            document.getElementById("dist-ps-breakdown").innerHTML = data.jam_ps_chart.breakdown.map(b => `<span class="badge bg-light text-dark border me-1 fw-normal">*${b.product} : ${b.count}</span>`).join('');
        }

        reChartInstance.data.labels = data.jam_re_chart.labels;
        reChartInstance.data.datasets[0].data = data.jam_re_chart.values;
        reChartInstance.update();
        document.getElementById("dist-re-count").textContent = `(${data.jam_re_chart.total || 0})`;
        if (document.getElementById("dist-re-breakdown") && data.jam_re_chart.breakdown) {
            document.getElementById("dist-re-breakdown").innerHTML = data.jam_re_chart.breakdown.map(b => `<span class="badge bg-light text-dark border me-1 fw-normal">*${b.product} : ${b.count}</span>`).join('');
        }

        // Update Matrix Table (compact: workzone hidden, tim, track_order, odc, status_morning)
        dataTable.clear();
        if (data.matrix_rows) {
          data.matrix_rows.forEach(row => {
            const esc = s => (s || "").toString()
              .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
              .replace(/"/g, "&quot;").replace(/'/g, "&#39;");

            const trackHtml = `<span class="badge rounded-pill bg-${row.color_class} text-white shadow-sm" style="font-size:0.75rem; padding: 0.35em 0.8em; letter-spacing: 0.01em;">${esc(row.track_order)}</span>`;
            const odcHtml = `<span class="text-muted fw-medium" style="font-size:0.70rem;" title="${esc(row.odc)}">${esc(row.odc) || "-"}</span>`;
            const statusHtml = `<span style="font-size:0.70rem;font-weight:700;text-transform:uppercase;color:#334155;">${esc(row.status_morning) || "KOSONG"}</span>`;
            const timFlagBadge = row.team_flag === "OGP"
              ? `<span class="badge-team-flag badge-ogp">*OGP</span>`
              : `<span class="badge-team-flag badge-idle">*IDLE</span>`;
            const timHtml = `<span class="fw-semibold text-uppercase" style="font-size:0.72rem;color:#334155;">${esc(row.tim) || "-"}${timFlagBadge}</span>`;
            const catatanHtml = `<span class="catatan-cell" style="font-size:0.70rem;color:#334155;white-space:pre-wrap;word-break:break-word;">${esc(row.catatan) || ""}</span>`;

            const rowNode = dataTable.row.add([
              row.workzone || "",
              timHtml,
              trackHtml,
              odcHtml,
              statusHtml,
              catatanHtml
            ]).node();

            $(rowNode).addClass(`matrix-compact-row bg-${row.color_class}-subtle`);
          });
        }
        dataTable.draw(false);

        // Update Kendala/Pending tables
        const getBadgeHtml = (val) => {
          const normalized = (val || "").toLowerCase().replace(/ /g, "-").replace(/\(/g, "").replace(/\)/g, "").replace(/\//g, "");
          if (!normalized) return `<span class="badge-soft badge-status-empty">${val || "EMPTY"}</span>`;
          return `<span class="badge-soft badge-status-${normalized}">${val || "EMPTY"}</span>`;
        };

        const buildSmallList = (containerId, rowData) => {
          const container = document.getElementById(containerId);
          if (!container) return;
          container.innerHTML = "";
          if (!rowData || rowData.length === 0) {
            container.innerHTML = '<div class="text-center text-muted p-4">Tidak ada data</div>';
          } else {
            rowData.forEach(r => {
              container.innerHTML += `<div class="compact-item">
                <div class="compact-info-row">
                  <div class="compact-tim-track">
                    <span class="compact-tim">${r.tim || "-"}</span>
                    <span class="compact-track" style="font-size:0.62rem;opacity:0.8;">${r.track_order || ""}</span>
                  </div>
                  <div class="compact-status">
                    ${getBadgeHtml(r.status_morning)}
                  </div>
                </div>
                <div class="compact-catatan">${r.catatan || ""}</div>
              </div>`;
            });
          }
        };

        if (data.kendala_fu) {
          const t = document.getElementById("title-kendala");
          if (t) t.textContent = `KENDALA TEKNIK NEED FU (${data.kendala_fu.length})`;
          buildSmallList("kendala-tbody", data.kendala_fu);
        }
        if (data.cek_pending) {
          const t = document.getElementById("title-pending");
          if (t) t.textContent = `CEK PENDING (${data.cek_pending.length})`;
          buildSmallList("cekpending-tbody", data.cek_pending);
        }

        // Update Top TIM panels
        const today_items = data.top_tim_today || [];
        const topTimTodayEl = document.getElementById("top-tim-today");
        if (topTimTodayEl) {
          topTimTodayEl.innerHTML = today_items.length === 0
            ? '<div class="text-center text-muted p-2">Belum ada PS Hari Ini</div>'
            : today_items.map(item => `<div class="d-flex justify-content-between align-items-center px-3 py-2" style="background:rgba(0,0,0,0.04);border-radius:8px;"><span class="fw-medium text-dark" style="font-size:0.95rem;">${item.tim}</span><span class="badge bg-success rounded-pill px-3" style="font-size:0.9rem;">${item.count}</span></div>`).join("");
        }

        const mtd_items = data.top_tim_mtd || [];
        const topTimMtdEl = document.getElementById("top-tim-mtd");
        if (topTimMtdEl) {
          topTimMtdEl.innerHTML = mtd_items.length === 0
            ? '<div class="text-center text-muted p-2">Belum ada PS Bulan Ini</div>'
            : mtd_items.map(item => `<div class="d-flex justify-content-between align-items-center px-3 py-2" style="background:rgba(0,0,0,0.04);border-radius:8px;"><span class="fw-medium text-dark" style="font-size:0.95rem;">${item.tim}</span><span class="badge bg-primary rounded-pill px-3" style="font-size:0.9rem;">${item.count}</span></div>`).join("");
        }

      })
      .catch(err => console.error("Error fetching dashboard data:", err));
  }

  // Auto-refresh every 16 minutes
  setInterval(updateDashboardData, 16 * 60 * 1000);

  // ─── Metric Card Drilldown ────────────────────────────────────────────────
  let drilldownTable = null;
  const detailModalElement = document.getElementById("detailModal");
  let detailModal;
  if (detailModalElement) {
    detailModal = new bootstrap.Modal(detailModalElement);
    detailModalElement.addEventListener("shown.bs.modal", function () {
      if (drilldownTable) drilldownTable.columns.adjust().draw();
    });
  }

  document.querySelectorAll(".metric-card").forEach(card => {
    card.addEventListener("click", function () {
      const type = this.getAttribute("data-drilldown-type");
      const sektor = new URLSearchParams(window.location.search).get("sektor") || "";
      if (!type) return;

      const titleMap = {
        total_ps: "Total PS",
        total_potensi: "Total Potensi",
        sedang_ogp: "Sedang OGP",
        oke_tarik: "Oke Tarik",
        belum_dikerjakan: "Belum Dikerjakan",
        undispatch: "Undispatch",
        idle_teams: "Tim Idle Status",
        perlu_failwa: "Order Perlu Di Failwa",
      };
      document.getElementById("detailModalLabel").textContent = "Data Detail: " + (titleMap[type] || "Data");

      const urlParams = new URLSearchParams(window.location.search);
      const startDate = urlParams.get("start_date") || "";
      const endDate = urlParams.get("end_date") || "";

      fetch(`/api/dashboard/detail?start_date=${startDate}&end_date=${endDate}&category=${type}&sektor=${sektor}`)
        .then(res => res.json())
        .then(data => {
          if (data.success && detailModal) {
            if ($.fn.DataTable.isDataTable("#drilldownTable")) {
              $("#drilldownTable").DataTable().destroy();
              $("#drilldownTable").empty();
            }

            const isFailwa = type === "perlu_failwa";
            const isIdle = type === "idle_teams";

            let theadHtml = "";
            if (isFailwa) {
              theadHtml = `<thead><tr><th>STATUS</th><th>TRACK ORDER</th><th>WORKORDER</th><th>STATUS MORNING</th><th>ODC</th><th>JENIS ORDER</th><th>CATATAN</th></tr></thead>`;
            } else if (isIdle) {
              theadHtml = `<thead><tr><th class="text-center">NAMA TIM IDLE (TANPA PEKERJAAN AKTIF)</th></tr></thead>`;
            } else {
              theadHtml = `<thead><tr><th>TRACK ORDER</th><th>WORKORDER</th><th>JENIS ORDER</th><th>ODC</th><th>TIM</th><th>STATUS MORNING</th><th>CATATAN</th></tr></thead>`;
            }

            $("#drilldownTable").html(theadHtml + "<tbody></tbody>");

            drilldownTable = $("#drilldownTable").DataTable({
              paging: true, pageLength: 10, searching: true, info: true,
              ordering: false, scrollX: true,
              language: {
                search: "Cari:", lengthMenu: "_MENU_ data",
                info: "_START_ - _END_ dari _TOTAL_ data",
                paginate: { previous: "←", next: "→" },
                zeroRecords: "Tidak ada data", infoEmpty: "Tidak ada data",
                infoFiltered: "(dari _MAX_ total)",
              },
            });

            const getBadgeHtml = val => {
              const n = (val || "").toLowerCase().replace(/ /g, "-").replace(/[()\/]/g, "");
              if (!n) return `<span class="badge-soft badge-status-empty">${val || "EMPTY"}</span>`;
              return `<span class="badge-soft badge-status-${n}">${val || "EMPTY"}</span>`;
            };

            data.data.forEach(row => {
              if (isFailwa) {
                drilldownTable.row.add([
                  row.status, row.track_order, row.workorder,
                  getBadgeHtml(row.status_morning),
                  row.odc, row.product_name || "-",
                  `<span title="${row.catatan || ""}">${row.catatan || "-"}</span>`,
                ]);
              } else if (isIdle) {
                drilldownTable.row.add([
                  `<div class="text-center py-2"><span class="fw-bold fs-6 text-primary">${row.tim}</span></div>`
                ]);
              } else {
                drilldownTable.row.add([
                  row.track_order, row.workorder, row.product_name || "-",
                  row.odc, row.tim,
                  getBadgeHtml(row.status_morning),
                  `<span title="${row.catatan || ""}">${row.catatan || "-"}</span>`,
                ]);
              }
            });
            drilldownTable.draw(false);
            detailModal.show();
          }
        })
        .catch(err => console.error("Error fetching detail data:", err));
    });
  });

  // ─── Sync Button ──────────────────────────────────────────────────────────
  const btnSync = document.getElementById("btnSync");
  const syncText = document.getElementById("syncText");
  if (btnSync) {
    btnSync.addEventListener("click", () => {
      btnSync.disabled = true;
      syncText.textContent = "Syncing...";
      fetch("/api/sync", { method: "POST" })
        .then(res => res.json())
        .then(data => {
          if (data.success) updateDashboardData();
          else console.error("Sync error:", data.message);
        })
        .catch(err => console.error("Sync request failed:", err))
        .finally(() => {
          btnSync.disabled = false;
          syncText.textContent = "Sync Sekarang";
        });
    });
  }

  // ─── Auto Sync (Setiap 16 Menit) ─────────────────────────────────────────
  setInterval(() => {
    if (btnSync && !btnSync.disabled) {
      console.log("Auto-sync triggered (16 menit)");
      btnSync.click();
    }
  }, 16 * 60 * 1000); // 16 Menit
})();
